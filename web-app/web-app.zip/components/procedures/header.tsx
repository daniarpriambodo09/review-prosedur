'use client';

export function Header() {
  return (
    <div className="bg-white px-8 py-4 flex justify-between items-center shadow-sm">
      <div className="flex items-center gap-2">
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          className="w-6 h-6 text-blue-600"
        >
          <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <span className="font-semibold text-blue-600">Review Prosedur</span>
      </div>
      <nav className="flex gap-8">
        <a href="#" className="text-sm text-slate-500 hover:text-blue-600">
          Dashboard Admin
        </a>
        <a href="#" className="text-sm text-slate-500 hover:text-blue-600">
          Panduan
        </a>
        <a href="#" className="text-sm text-slate-500 hover:text-blue-600">
          Kelola User
        </a>
        <a href="#" className="text-sm text-slate-500 hover:text-blue-600">
          Admin
        </a>
      </nav>
    </div>
  );
}
