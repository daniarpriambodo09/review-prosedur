// app/review-page-owner/PIC-MCB/page.tsx

'use client';

import { useState, useEffect } from 'react';

type StatusType = 'Relevan' | 'Revisi' | 'Obsolete' | '-';

interface DocumentRow {
  namaDokumen: string;
  nomorDokumen: string;
  levelDokumen: string;
  tanggalSelesaiApproval: string;
  revisi: string;
  owner: string;
  pic: string;
  status: StatusType;
}

const INITIAL_DATA: DocumentRow[] = [
  { namaDokumen: 'Perhitungan Dan Order Kebutuhan Mesin Produksi', nomorDokumen: 'PFP-W-01', levelDokumen: '3', tanggalSelesaiApproval: '2023-10-19 00:00:00', revisi: '3', owner: 'MTC ', pic: 'MCB', status: '-' },
  { namaDokumen: 'Set up Tooling Applikator', nomorDokumen: 'ETM-W-04', levelDokumen: '3', tanggalSelesaiApproval: '2025-07-22 00:00:00', revisi: '4', owner: 'MTC', pic: 'MCB', status: '-' },
  { namaDokumen: 'Modifikasi  Applicator', nomorDokumen: 'ETM-W-05', levelDokumen: '3', tanggalSelesaiApproval: '2025-07-22 00:00:00', revisi: '5', owner: 'MTC', pic: 'MCB', status: '-' },
  { namaDokumen: 'Penyediaan dan Pengelolaan Spare Part', nomorDokumen: 'ETM-W-07', levelDokumen: '3', tanggalSelesaiApproval: '2025-07-10 00:00:00', revisi: '9', owner: 'MTC', pic: 'MCB', status: '-' },
  { namaDokumen: 'Mapping Applikator', nomorDokumen: 'ETM-W-10', levelDokumen: '3', tanggalSelesaiApproval: '2025-10-27 00:00:00', revisi: '4', owner: 'MTC', pic: 'MCB', status: '-' },
  { namaDokumen: 'Tooling Control Maintenance', nomorDokumen: 'ETM-W-13', levelDokumen: '3', tanggalSelesaiApproval: '2025-11-10 00:00:00', revisi: '7', owner: 'MTC', pic: 'MCB', status: '-' },
  { namaDokumen: 'Sistem Informasi Perubahan Posisi Applicator', nomorDokumen: 'ETM-W-15', levelDokumen: '3', tanggalSelesaiApproval: '2025-07-24 00:00:00', revisi: '3', owner: 'MTC', pic: 'MCB', status: '-' },
  { namaDokumen: 'Preventive and Predictive Maintenance Mesin Produksi & Applicator', nomorDokumen: 'PPM-W-01', levelDokumen: '3', tanggalSelesaiApproval: '2024-08-01 00:00:00', revisi: '7', owner: 'MTC', pic: 'MCB', status: '-' },
  { namaDokumen: 'Penanganan Kerusakan Pada Mesin Produksi', nomorDokumen: 'PPM-W-03', levelDokumen: '3', tanggalSelesaiApproval: '2025-08-13 00:00:00', revisi: '3', owner: 'MTC', pic: 'MCB', status: '-' },
  { namaDokumen: 'Pelaksanaan  Evaluasi Preventive Maintenance Mesin Produksi', nomorDokumen: 'PPM-W-05', levelDokumen: '3', tanggalSelesaiApproval: '2025-07-22 00:00:00', revisi: '5', owner: 'MTC ', pic: 'MCB', status: '-' },
  { namaDokumen: 'Pengisian Checksheet Patroli Harian Mesin', nomorDokumen: 'PPM-W-10', levelDokumen: '3', tanggalSelesaiApproval: '2025-10-27 00:00:00', revisi: '1', owner: 'MTC', pic: 'MCB', status: '-' },
  { namaDokumen: 'Review Dokumen (Checksheet) Mesin & Equipment Produksi', nomorDokumen: 'PPM-W-11', levelDokumen: '3', tanggalSelesaiApproval: '2025-08-13 00:00:00', revisi: '1', owner: 'MTC', pic: 'MCB', status: '-' },
];

const MONTH_NAMES = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

function getMonthFromISO(iso: string): string {
  const d = new Date(iso);
  return isNaN(d.getTime()) ? '' : MONTH_NAMES[d.getMonth()];
}

function formatToDDMonYYYY(iso: string): string {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return `${d.getDate()}-${MONTH_NAMES[d.getMonth()]}-${d.getFullYear()}`;
}

const statusClassMap: Record<StatusType, string> = {
  Relevan: "bg-green-100 text-green-800 border-green-300",
  Revisi: "bg-yellow-100 text-yellow-800 border-yellow-300",
  Obsolete: "bg-red-100 text-red-800 border-red-300",
  "-": "bg-gray-100 text-gray-500 border-gray-300",
};

function StatusSelect({ value, onChange }: { value: StatusType; onChange: (s: StatusType) => void }) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value as StatusType)}
      className={`px-3 py-1.5 border rounded text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 ${statusClassMap[value]}`}
    >
      <option value="-" disabled>— Belum Dipilih —</option>
      <option value="Relevan">Relevan</option>
      <option value="Revisi">Revisi</option>
      <option value="Obsolete">Obsolete</option>
    </select>
  );
}

function DocumentTable({ data, onStatusChange }: { 
   data : DocumentRow[]; 
  onStatusChange: (nomorDokumen: string, status: StatusType) => void; 
}) {
  if (data.length === 0) return <div className="text-center py-10 text-slate-500">Tidak ada dokumen untuk bulan ini.</div>;
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full border-collapse">
        <thead>
          <tr className="bg-slate-50">
            {['Nama Dokumen','Nomor Dokumen','Level Dokumen','Tanggal Selesai Approval','Revisi','Owner','PIC','Status'].map(h => (
              <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-slate-600 border-b border-slate-200">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row) => (
            <tr key={row.nomorDokumen} className="hover:bg-slate-50">
              <td className="px-4 py-3 text-sm text-slate-700 border-b border-slate-100">{row.namaDokumen}</td>
              <td className="px-4 py-3 text-sm text-slate-700 border-b border-slate-100">{row.nomorDokumen}</td>
              <td className="px-4 py-3 text-sm text-slate-700 border-b border-slate-100">{row.levelDokumen}</td>
              <td className="px-4 py-3 text-sm text-slate-700 border-b border-slate-100">{formatToDDMonYYYY(row.tanggalSelesaiApproval)}</td>
              <td className="px-4 py-3 text-sm text-slate-700 border-b border-slate-100">{row.revisi}</td>
              <td className="px-4 py-3 text-sm text-slate-700 border-b border-slate-100">{row.owner}</td>
              <td className="px-4 py-3 text-sm text-slate-700 border-b border-slate-100">{row.pic}</td>
              <td className="px-4 py-3 border-b border-slate-100">
                <StatusSelect
                  value={row.status}
                  onChange={(status) => onStatusChange(row.nomorDokumen, status)}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function PicReviewPageMCB() {
  const [documents, setDocuments] = useState<DocumentRow[]>(INITIAL_DATA);
  const [currentMonthAbbr, setCurrentMonthAbbr] = useState('');

  useEffect(() => {
    setCurrentMonthAbbr(MONTH_NAMES[new Date().getMonth()]);
  }, []);

  const filteredData = documents.filter(row => getMonthFromISO(row.tanggalSelesaiApproval) === currentMonthAbbr);

  const handleStatusChange = (nomorDokumen: string, status: StatusType) => {
    setDocuments(prev =>
      prev.map(doc =>
        doc.nomorDokumen === nomorDokumen ? { ...doc, status } : doc
      )
    );
  };

  const handleFinish = () => {
    alert('Perubahan telah disimpan. Terima kasih!');
  };

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="px-6 py-5 border-b border-slate-200">
          <h1 className="text-xl font-semibold text-slate-800">Review Prosedur</h1>
          <p className="text-sm text-slate-600 mt-1">PIC: <span className="font-medium">MCB</span></p>
        </div>
        <div className="p-6">
          <DocumentTable data={filteredData} onStatusChange={handleStatusChange} />
        </div>
        <div className="px-6 pb-6">
          <button
            onClick={handleFinish}
            className="bg-blue-600 text-white px-6 py-2.5 rounded text-sm font-medium hover:bg-blue-700 transition"
          >
            Selesai
          </button>
        </div>
        <div className="px-6 py-4 text-xs text-slate-500 bg-slate-50 border-t border-slate-200">
          Hanya menampilkan dokumen dengan tanggal approval pada bulan {currentMonthAbbr}. Status awal: belum dipilih ("–").
        </div>
      </div>
    </div>
  );
}