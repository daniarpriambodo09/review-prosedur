// app/status-review/page.tsx
'use client';
import { useState, useMemo, useEffect } from 'react';
import { Header } from '@/components/procedures/header';
import { RAW_EXCEL_ROWS } from '@/data/data_review/all-data-table';

// Tambahkan status "Menunggu" dan "-"
type StatusType = 'Revisi' | 'Relevan' | 'Obsolete' | 'Menunggu' | '-';

interface ProcedureRowWithStatus {
  nama: string;
  nomorDokumen: string;
  level: string;
  tanggal: string; // ISO format: YYYY-MM-DD
  revisi: string;
  owner: string;
  pic: string;
  status: StatusType;
}

// Breadcrumb Component
function Breadcrumb() {
  return (
    <div className="px-8 py-5 text-sm text-slate-500">
      <a href="#" className="text-blue-600 hover:underline">Dashboard Admin</a>
      <span> / Status Prosedur</span>
    </div>
  );
}

// Status Badge Component
function StatusBadge({ status }: { status: StatusType }) {
  const styles: Record<StatusType, { bg: string; text: string; icon: string }> = {
    Revisi: { bg: 'bg-amber-100', text: 'text-amber-900', icon: '⟳' },
    Relevan: { bg: 'bg-emerald-100', text: 'text-emerald-900', icon: '✓' },
    Obsolete: { bg: 'bg-red-100', text: 'text-red-900', icon: '⊘' },
    Menunggu: { bg: 'bg-blue-100', text: 'text-blue-900', icon: '⏳' },
    '-': { bg: 'bg-gray-100', text: 'text-gray-500', icon: '?' },
  };
  const { bg, text, icon } = styles[status] || styles['-'];
  return (
    <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium whitespace-nowrap ${bg} ${text}`}>
      {icon} {status}
    </span>
  );
}

// Controls Component
function Controls({
  searchValue,
  filterValue,
  onSearchChange,
  onFilterChange,
  onAddProcedure,
}: {
  searchValue: string;
  filterValue: string;
  onSearchChange: (value: string) => void;
  onFilterChange: (value: string) => void;
  onAddProcedure: () => void;
}) {
  return (
    <div className="flex gap-4 mb-6">
      <div className="relative flex-1 max-w-xs">
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4.5 h-4.5 text-slate-400"
        >
          <circle cx="11" cy="11" r="8" />
          <path d="m21 21-4.35-4.35" />
        </svg>
        <input
          type="text"
          placeholder="Cari prosedur..."
          value={searchValue}
          onChange={(e) => onSearchChange(e.target.value)}
          className="text-black w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded text-sm focus:outline-none focus:border-blue-600"
        />
      </div>
      <select
        value={filterValue}
        onChange={(e) => onFilterChange(e.target.value)}
        className="text-black px-4 py-2.5 border border-slate-200 rounded text-sm bg-white cursor-pointer focus:outline-none focus:border-blue-600 appearance-none bg-right bg-no-repeat pr-8"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%2364748b' d='M6 8L2 4h8z'/%3E%3C/svg%3E")`,
          backgroundPosition: 'right 12px center',
        }}
      >
        <option value="">Filter Status</option>
        <option value="Revisi">Revisi</option>
        <option value="Relevan">Relevan</option>
        <option value="Obsolete">Obsolete</option>
        <option value="Menunggu">Menunggu</option>
        <option value="-">Belum Ditentukan</option>
      </select>
      <button
        onClick={onAddProcedure}
        className="bg-blue-600 text-white px-5 py-2.5 rounded text-sm font-medium flex items-center gap-2 hover:bg-blue-700"
      >
        <span>+</span> Tambah Prosedur
      </button>
    </div>
  );
}

// Procedures Table Component
function ProceduresTable({ data }: { data: ProcedureRowWithStatus[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr>
            {['Nama Dokumen','Nomor Dokumen','Level Dokumen','Tanggal Selesai Approval','Revisi','Owner','PIC','Status'].map(h => (
              <th key={h} className="bg-slate-50 px-5 py-3 text-left text-xs font-semibold text-slate-600 border-b border-slate-200">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, index) => (
            <tr key={`${row.nomorDokumen}-${index}`} className="hover:bg-slate-50">
              <td className="px-5 py-4 text-sm text-slate-700 border-b border-slate-100">{row.nama}</td>
              <td className="px-5 py-4 text-sm text-slate-700 border-b border-slate-100">{row.nomorDokumen}</td>
              <td className="px-5 py-4 text-sm text-slate-700 border-b border-slate-100">{row.level}</td>
              <td className="px-5 py-4 text-sm text-slate-700 border-b border-slate-100">{row.tanggal}</td>
              <td className="px-5 py-4 text-sm text-slate-700 border-b border-slate-100">{row.revisi}</td>
              <td className="px-5 py-4 text-sm text-slate-700 border-b border-slate-100">{row.owner}</td>
              <td className="px-5 py-4 text-sm text-slate-700 border-b border-slate-100">{row.pic}</td>
              <td className="px-5 py-4 text-sm text-slate-700 border-b border-slate-100">
                <StatusBadge status={row.status} />
              </td>
            </tr>
          ))}
          {data.length === 0 && (
            <tr>
              <td colSpan={8} className="px-5 py-8 text-center text-sm text-slate-500">Tidak ada data prosedur</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

// Pagination Component
function Pagination({
  currentPage,
  totalPages,
  startIndex,
  endIndex,
  totalItems,
  onPrevious,
  onNext,
}: {
  currentPage: number;
  totalPages: number;
  startIndex: number;
  endIndex: number;
  totalItems: number;
  onPrevious: () => void;
  onNext: () => void;
}) {
  return (
    <div className="flex justify-between items-center px-5 py-5 border-t border-slate-200">
      <div className="text-sm text-slate-500">
        Menampilkan {startIndex} sampai {endIndex} dari {totalItems} entri
      </div>
      <div className="flex gap-2">
        <button
          onClick={onPrevious}
          disabled={currentPage === 1}
          className="w-8 h-8 border border-slate-200 bg-white rounded text-sm font-medium text-slate-600 flex items-center justify-center hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          ‹
        </button>
        <button disabled className="w-8 h-8 border border-blue-600 bg-blue-600 rounded text-sm font-medium text-white flex items-center justify-center">
          {currentPage}
        </button>
        <button
          onClick={onNext}
          disabled={currentPage >= totalPages}
          className="w-8 h-8 border border-slate-200 bg-white rounded text-sm font-medium text-slate-600 flex items-center justify-center hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          ›
        </button>
      </div>
    </div>
  );
}

// Helper: Parse Excel date like "1-Oct-25" → "2025-10-01"
function parseExcelDate(dateStr: string): string {
  const [day, month, year] = dateStr.split('-');
  const months: Record<string, string> = {
    Jan: '01', Feb: '02', Mar: '03', Apr: '04', May: '05', Jun: '06',
    Jul: '07', Aug: '08', Sep: '09', Oct: '10', Nov: '11', Dec: '12',
  };
  const paddedDay = day.padStart(2, '0');
  const monthNum = months[month];
  if (!monthNum) return '1970-01-01';
  const fullYear = parseInt(year, 10) < 50 ? `20${year}` : `19${year}`;
  return `${fullYear}-${monthNum}-${paddedDay}`;
}

const ROWS_PER_PAGE = 10;

// Modal Form Component (tanpa input Revisi)
function AddProcedureModal({
  isOpen,
  onClose,
  onSave,
  value,
  onChange,
}: {
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
  value: Omit<ProcedureRowWithStatus, 'status' | 'revisi'> & { revisi?: string };
  onChange: (
  field: keyof Omit<ProcedureRowWithStatus, 'status' | 'revisi'>,
  val: string
) => void;

}) {
  if (!isOpen) return null;

  const handleSave = () => {
    if (
      !value.nama ||
      !value.nomorDokumen ||
      !value.level ||
      !value.tanggal ||
      !value.owner ||
      !value.pic
    ) {
      alert('Semua kolom wajib diisi.');
      return;
    }
    onSave();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-2xl">
        <div className="px-6 py-4 border-b border-slate-200">
          <h2 className="text-lg font-semibold text-slate-900">Tambah Prosedur Baru</h2>
        </div>
        <div className="p-6 space-y-4">
          {([
            { label: 'Nama Dokumen', key: 'nama' },
            { label: 'Nomor Dokumen', key: 'nomorDokumen' },
            { label: 'Level Dokumen', key: 'level' },
            { label: 'Owner', key: 'owner' },
            { label: 'PIC', key: 'pic' },
          ] as const).map(({ label, key }) => (
            <div key={key}>
              <label className="block text-sm font-medium text-slate-700 mb-1">{label}</label>
              <input
                type="text"
                value={value[key] || ''}
                onChange={(e) => onChange(key, e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>
          ))}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Tanggal Selesai Approval (YYYY-MM-DD)
            </label>
            <input
              type="date"
              value={value.tanggal || ''}
              onChange={(e) => onChange('tanggal', e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>
        <div className="px-6 py-4 flex justify-end gap-3 border-t border-slate-200">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm text-slate-600 hover:bg-slate-100 rounded"
          >
            Batal
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
          >
            Simpan
          </button>
        </div>
      </div>
    </div>
  );
}

export default function StatusReviewPage() {
  const [searchValue, setSearchValue] = useState('');
  const [filterValue, setFilterValue] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [dataWithStatus, setDataWithStatus] = useState<ProcedureRowWithStatus[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newProcedure, setNewProcedure] = useState<Omit<ProcedureRowWithStatus, 'status' | 'revisi'>>({
    nama: '',
    nomorDokumen: '',
    level: '',
    tanggal: '',
    owner: '',
    pic: '',
  });

  // Load initial data + localStorage
  useEffect(() => {
    const currentMonth = new Date().getMonth();
    const updated = RAW_EXCEL_ROWS.map((row) => {
      const isoDate = parseExcelDate(row.tanggal);
      const docMonth = new Date(isoDate).getMonth();

      let status: StatusType = docMonth === currentMonth ? 'Menunggu' : 'Relevan';
      let revisi = row.revisi;

      if (typeof window !== 'undefined') {
        const stored = localStorage.getItem(`document-review-${row.nomorDokumen}`);
        if (stored) {
          try {
            const parsed = JSON.parse(stored);
            if (parsed.revisi !== undefined) revisi = String(parsed.revisi);
            if (parsed.lastReviewedMonth === currentMonth) status = parsed.status;
          } catch {}
        }
      }

      return {
        ...row,
        tanggal: isoDate,
        revisi,
        status,
      };
    });
    setDataWithStatus(updated);
  }, []);

  const handleNewProcedureChange = (
    field: keyof Omit<ProcedureRowWithStatus, 'status' | 'revisi'>,
    value: string
  ) => {
    setNewProcedure((prev) => ({ ...prev, [field]: value }));
  };

  const handleSaveNewProcedure = () => {
    const currentMonth = new Date().getMonth();
    const docMonth = new Date(newProcedure.tanggal).getMonth();
    const status: StatusType = docMonth === currentMonth ? 'Menunggu' : 'Relevan';

    const newEntry: ProcedureRowWithStatus = {
      ...newProcedure,
      revisi: '0', // default revisi
      status,
    };

    // Simpan ke localStorage
    if (typeof window !== 'undefined') {
      localStorage.setItem(
        `document-review-${newProcedure.nomorDokumen}`,
        JSON.stringify({
          revisi: '0',
          status,
          lastReviewedMonth: currentMonth,
        })
      );
    }

    setDataWithStatus((prev) => [newEntry, ...prev]);
    setNewProcedure({
      nama: '',
      nomorDokumen: '',
      level: '',
      tanggal: '',
      owner: '',
      pic: '',
    });
    setIsModalOpen(false);
    setCurrentPage(1);
  };

  const filteredData = useMemo(() => {
    let result = dataWithStatus;
    if (searchValue) {
      const searchLower = searchValue.toLowerCase();
      result = result.filter((row) => row.nama.toLowerCase().includes(searchLower));
    }
    if (filterValue) {
      result = result.filter((row) => row.status === filterValue);
    }
    return result;
  }, [searchValue, filterValue, dataWithStatus]);

  const handleSearchChange = (value: string) => {
    setSearchValue(value);
    setCurrentPage(1);
  };

  const handleFilterChange = (value: string) => {
    setFilterValue(value);
    setCurrentPage(1);
  };

  const totalPages = Math.ceil(filteredData.length / ROWS_PER_PAGE);
  const startIndex = (currentPage - 1) * ROWS_PER_PAGE + 1;
  const endIndex = Math.min(currentPage * ROWS_PER_PAGE, filteredData.length);
  const pageData = filteredData.slice((currentPage - 1) * ROWS_PER_PAGE, currentPage * ROWS_PER_PAGE);

  const handlePrevious = () => {
    if (currentPage > 1) setCurrentPage(currentPage - 1);
  };

  const handleNext = () => {
    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
  };

  const handleAddProcedure = () => {
    setIsModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-100">
      <Header />
      <Breadcrumb />
      <div className="px-8 pb-8">
        <h1 className="text-3xl font-semibold text-slate-900 mb-2">Status Prosedur</h1>
        <p className="text-sm text-slate-500 mb-8">
          Kelola status evaluasi prosedur yang Ada, kirim lainkan.
        </p>
        <Controls
          searchValue={searchValue}
          filterValue={filterValue}
          onSearchChange={handleSearchChange}
          onFilterChange={handleFilterChange}
          onAddProcedure={handleAddProcedure}
        />
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="px-5 py-5 border-b border-slate-200 font-semibold text-base text-slate-900">
            Dokumen Prosedur
          </div>
          <ProceduresTable data={pageData} />
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            startIndex={startIndex}
            endIndex={endIndex}
            totalItems={filteredData.length}
            onPrevious={handlePrevious}
            onNext={handleNext}
          />
        </div>
      </div>

      {/* Modal Tambah Prosedur */}
      <AddProcedureModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveNewProcedure}
        value={newProcedure}
        onChange={handleNewProcedureChange}
      />
    </div>
  );
}